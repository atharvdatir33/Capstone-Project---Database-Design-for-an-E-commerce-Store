// Currency formatter for INR
const money = (n) => `₹${Number(n || 0).toLocaleString('en-IN')}`;

// Local cart state
let cart = [];

// Category icon map
const icons = {
  Clothing: '👕',
  Accessories: '⚡',
  Stationery: '📓'
};

// Generic fetch helper
async function get(path) {
  try {
    const res = await fetch(path);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (err) {
    console.error(`Failed to fetch ${path}:`, err);
    return [];
  }
}

// Render the cart drawer contents
function renderCart() {
  const container = document.querySelector('#cart-items');
  const countEl = document.querySelector('#cart-count');
  const totalEl = document.querySelector('#cart-total');

  if (!container) return;

  if (cart.length === 0) {
    container.innerHTML = `
      <div class="empty-cart">
        <p>Your cart is empty</p>
        <small>Explore the NexaMart collection to add items!</small>
      </div>
    `;
  } else {
    container.innerHTML = cart.map(item => `
      <div class="cart-item">
        <div class="cart-item-info">
          <strong>${item.product_name}</strong>
          <br>
          <small>${money(item.price)} × ${item.quantity}</small>
        </div>
        <div class="cart-item-controls">
          <button type="button" class="qty-btn" onclick="changeQty(${item.product_id}, -1)">−</button>
          <span class="qty-val">${item.quantity}</span>
          <button type="button" class="qty-btn" onclick="changeQty(${item.product_id}, 1)">+</button>
        </div>
      </div>
    `).join('');
  }

  const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const totalCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  if (totalEl) totalEl.textContent = money(total);
  if (countEl) countEl.textContent = totalCount;
}

// Add item to cart
window.add = function (item) {
  const existing = cart.find(x => x.product_id === item.product_id);
  if (existing) {
    if (existing.quantity < item.stock) {
      existing.quantity += 1;
    } else {
      alert(`Only ${item.stock} units available in stock!`);
    }
  } else {
    cart.push({ ...item, quantity: 1 });
  }
  renderCart();
  // Open drawer automatically on add
  const drawer = document.querySelector('#drawer');
  const overlay = document.querySelector('#overlay');
  if (drawer && overlay) {
    drawer.classList.add('open');
    overlay.classList.add('show');
  }
};

// Change item quantity in cart
window.changeQty = function (id, delta) {
  const item = cart.find(x => x.product_id === id);
  if (!item) return;

  item.quantity += delta;
  if (item.quantity <= 0) {
    cart = cart.filter(x => x.product_id !== id);
  }
  renderCart();
};

// Load and render products catalogue
async function loadProducts() {
  const searchInput = document.querySelector('#search');
  const categorySelect = document.querySelector('#category');
  const productsContainer = document.querySelector('#products');

  if (!productsContainer) return;

  const searchVal = searchInput ? searchInput.value.trim() : '';
  const catVal = categorySelect ? categorySelect.value : 'All';

  const params = new URLSearchParams({ search: searchVal, category: catVal });
  const products = await get('/api/products?' + params.toString());

  if (!Array.isArray(products) || products.length === 0) {
    productsContainer.innerHTML = `
      <div class="no-results">
        <p>No NexaMart items match your search.</p>
      </div>
    `;
    return;
  }

  productsContainer.innerHTML = products.map(p => `
    <article class="product">
      <div class="product-icon">${icons[p.category] || '📦'}</div>
      <span class="product-category-tag">${p.category.toUpperCase()}</span>
      <h3>${p.product_name}</h3>
      <p class="stock-info">${p.stock} units available</p>
      <div class="bottom">
        <strong class="price">${money(p.price)}</strong>
        <button class="add-btn" type="button" onclick='add(${JSON.stringify(p)})'>
          <span>+ Add</span>
        </button>
      </div>
    </article>
  `).join('');
}

// Load and render live SQL dashboard metrics & recent orders
async function dashboard() {
  const data = await get('/api/dashboard');
  if (!data || !data.summary) return;

  const s = data.summary;
  const metricsContainer = document.querySelector('#metrics');
  if (metricsContainer) {
    metricsContainer.innerHTML = [
      ['Total Revenue', money(s.total_revenue), '💰'],
      ['Total Orders', s.total_orders, '📦'],
      ['Active Customers', s.total_customers, '👥'],
      ['Low Stock Items', s.low_stock, '⚠️']
    ].map(m => `
      <div class="metric">
        <div class="metric-icon">${m[2]}</div>
        <strong>${m[1]}</strong>
        <span>${m[0]}</span>
      </div>
    `).join('');
  }

  const bestSellersContainer = document.querySelector('#best-sellers');
  if (bestSellersContainer && Array.isArray(data.best_sellers)) {
    bestSellersContainer.innerHTML = data.best_sellers.map(item => `
      <li>
        <span class="item-name">${item.product_name}</span>
        <b class="item-badge">${item.total_sold} sold</b>
      </li>
    `).join('');
  }

  const topCustContainer = document.querySelector('#top-customers');
  if (topCustContainer && Array.isArray(data.top_customers)) {
    topCustContainer.innerHTML = data.top_customers.map(cust => `
      <li>
        <span class="item-name">${cust.name}</span>
        <b class="item-badge">${money(cust.total_spent)}</b>
      </li>
    `).join('');
  }

  const orders = await get('/api/orders');
  const ordersBody = document.querySelector('#orders-body');
  if (ordersBody && Array.isArray(orders)) {
    ordersBody.innerHTML = orders.map(ord => `
      <tr>
        <td><strong>#${ord.order_id}</strong></td>
        <td>${ord.customer}</td>
        <td>${ord.order_date}</td>
        <td><span class="status status-${(ord.order_status || '').toLowerCase()}">${ord.order_status}</span></td>
        <td><strong>${money(ord.amount)}</strong></td>
      </tr>
    `).join('');
  }
}

// Initial setup on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  const drawer = document.querySelector('#drawer');
  const overlay = document.querySelector('#overlay');
  const cartBtn = document.querySelector('#cart-button');
  const closeBtn = document.querySelector('#close-cart');
  const searchInput = document.querySelector('#search');
  const categorySelect = document.querySelector('#category');
  const checkoutForm = document.querySelector('#checkout');
  const messageEl = document.querySelector('#message');

  if (cartBtn && drawer && overlay) {
    cartBtn.onclick = () => {
      drawer.classList.add('open');
      overlay.classList.add('show');
    };
  }

  const closeDrawer = () => {
    if (drawer) drawer.classList.remove('open');
    if (overlay) overlay.classList.remove('show');
  };

  if (closeBtn) closeBtn.onclick = closeDrawer;
  if (overlay) overlay.onclick = closeDrawer;

  if (searchInput) {
    searchInput.addEventListener('input', loadProducts);
  }

  if (categorySelect) {
    categorySelect.addEventListener('change', loadProducts);
  }

  if (checkoutForm) {
    checkoutForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!cart.length) {
        if (messageEl) {
          messageEl.textContent = 'Please add at least one item to your cart.';
          messageEl.style.color = '#ef4444';
        }
        return;
      }

      const formData = new FormData(checkoutForm);
      const payload = {
        name: formData.get('name'),
        email: formData.get('email'),
        city: formData.get('city'),
        items: cart
      };

      try {
        const res = await fetch('/api/checkout', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        const result = await res.json();

        if (result.error) {
          if (messageEl) {
            messageEl.textContent = result.error;
            messageEl.style.color = '#ef4444';
          }
        } else {
          if (messageEl) {
            messageEl.textContent = `✓ NexaMart Order #${result.order_id} placed successfully! Total: ${money(result.total)}`;
            messageEl.style.color = '#059669';
          }
          cart = [];
          renderCart();
          checkoutForm.reset();
          loadProducts();
          dashboard();
        }
      } catch (err) {
        if (messageEl) {
          messageEl.textContent = 'Network error during checkout. Please retry.';
          messageEl.style.color = '#ef4444';
        }
      }
    });
  }

  // Load initial data
  loadProducts();
  dashboard();
  renderCart();
});
