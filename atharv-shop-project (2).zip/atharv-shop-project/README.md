# NexaMart — SQL Database Capstone

An interactive e-commerce storefront built around the supplied NexaMart relational-database brief. It uses Python's built-in HTTP server and SQLite, so there are no package installs or external services required.

## Run

```powershell
python app.py
```

Then open [http://localhost:8000](http://localhost:8000). On its first run, the application creates `atharvshop.db` from `schema.sql` and `seed.sql`.

## What it demonstrates

- Normalized customer, product, order, order-item, and payment tables with foreign keys and integrity checks.
- A product catalogue with live text search and category filtering.
- An interactive cart and checkout flow that creates customers/orders/payment records and decrements stock in one database transaction.
- SQL-driven dashboard metrics: revenue, orders, customers, low stock, best sellers, top customers, and recent orders.

## Analysis queries

The dashboard's query patterns can be found in `app.py`. Example revenue by product query:

```sql
SELECT p.product_name, SUM(oi.quantity * p.price) AS revenue
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
JOIN orders o ON oi.order_id = o.order_id
WHERE o.order_status = 'Delivered'
GROUP BY p.product_id
ORDER BY revenue DESC;
```

To reset the demonstration data, stop the server, delete `atharvshop.db`, and run `python app.py` again.
