"""Atharv Shop: a lightweight SQLite-backed interactive storefront."""
import json
import mimetypes
import sqlite3
from datetime import date
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).parent
DB_PATH = ROOT / "harryshop.db"


def connection():
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")
    return db


def setup_database():
    """Create the database once from the schema and seed scripts."""
    if DB_PATH.exists():
        return
    with connection() as db:
        db.executescript((ROOT / "schema.sql").read_text(encoding="utf-8"))
        db.executescript((ROOT / "seed.sql").read_text(encoding="utf-8"))


def rows(query, parameters=()):
    with connection() as db:
        return [dict(row) for row in db.execute(query, parameters).fetchall()]


class AtharvShopHandler(SimpleHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print("[Atharv Shop] " + fmt % args)

    def send_json(self, data, status=HTTPStatus.OK):
        body = json.dumps(data, default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/products":
            params = parse_qs(parsed.query)
            search = params.get("search", [""])[0].strip()
            category = params.get("category", ["All"])[0]
            sql = "SELECT * FROM products WHERE stock > 0"
            values = []
            if search:
                sql += " AND product_name LIKE ?"
                values.append(f"%{search}%")
            if category != "All":
                sql += " AND category = ?"
                values.append(category)
            sql += " ORDER BY product_id"
            return self.send_json(rows(sql, values))

        if parsed.path == "/api/dashboard":
            return self.send_json({
                "summary": rows("""SELECT
                    COALESCE(SUM(amount), 0) AS total_revenue,
                    (SELECT COUNT(*) FROM orders) AS total_orders,
                    (SELECT COUNT(*) FROM customers) AS total_customers,
                    (SELECT COUNT(*) FROM products WHERE stock < 50) AS low_stock
                    FROM payments""")[0],
                "best_sellers": rows("""SELECT p.product_name, SUM(oi.quantity) AS total_sold
                    FROM order_items oi JOIN products p ON p.product_id = oi.product_id
                    GROUP BY p.product_id ORDER BY total_sold DESC, p.product_name LIMIT 5"""),
                "top_customers": rows("""SELECT c.name, SUM(p.amount) AS total_spent
                    FROM customers c JOIN orders o ON o.customer_id = c.customer_id
                    JOIN payments p ON p.order_id = o.order_id
                    GROUP BY c.customer_id ORDER BY total_spent DESC LIMIT 5"""),
            })

        if parsed.path == "/api/orders":
            return self.send_json(rows("""SELECT o.order_id, c.name AS customer, o.order_date,
                o.order_status, COALESCE(p.amount, 0) AS amount
                FROM orders o JOIN customers c ON c.customer_id = o.customer_id
                LEFT JOIN payments p ON p.order_id = o.order_id ORDER BY o.order_id DESC LIMIT 20"""))

        if parsed.path == "/":
            self.path = "/static/index.html"
        elif parsed.path.startswith("/static/"):
            self.path = parsed.path
        else:
            self.send_error(HTTPStatus.NOT_FOUND, "Not found")
            return
        return super().do_GET()

    def do_POST(self):
        if urlparse(self.path).path != "/api/checkout":
            self.send_error(HTTPStatus.NOT_FOUND, "Not found")
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            payload = json.loads(self.rfile.read(length))
            name, email, city = (payload.get(k, "").strip() for k in ("name", "email", "city"))
            items = payload.get("items", [])
            if not all((name, email, city)) or not items:
                raise ValueError("Enter your name, email, city, and at least one item.")
            with connection() as db:
                customer = db.execute("SELECT customer_id FROM customers WHERE email = ?", (email,)).fetchone()
                if customer:
                    customer_id = customer["customer_id"]
                else:
                    customer_id = db.execute("INSERT INTO customers(name,email,city,signup_date) VALUES(?,?,?,?)",
                                             (name, email, city, date.today())).lastrowid
                product_ids = [int(item["product_id"]) for item in items]
                placeholders = ",".join("?" for _ in product_ids)
                products = {r["product_id"]: r for r in db.execute(
                    f"SELECT product_id, product_name, price, stock FROM products WHERE product_id IN ({placeholders})", product_ids)}
                total = 0
                for item in items:
                    product, qty = products.get(int(item["product_id"])), int(item["quantity"])
                    if not product or qty < 1 or qty > product["stock"]:
                        raise ValueError("One or more product quantities are unavailable.")
                    total += product["price"] * qty
                order_id = db.execute("INSERT INTO orders(customer_id,order_date,order_status) VALUES(?,?,?)",
                                      (customer_id, date.today(), "Processing")).lastrowid
                for item in items:
                    product_id, qty = int(item["product_id"]), int(item["quantity"])
                    db.execute("INSERT INTO order_items(order_id,product_id,quantity) VALUES(?,?,?)", (order_id, product_id, qty))
                    db.execute("UPDATE products SET stock = stock - ? WHERE product_id = ?", (qty, product_id))
                db.execute("INSERT INTO payments(order_id,payment_mode,amount,payment_date) VALUES(?,?,?,?)",
                           (order_id, "Demo Checkout", total, date.today()))
            self.send_json({"order_id": order_id, "total": total}, HTTPStatus.CREATED)
        except (ValueError, KeyError, json.JSONDecodeError) as error:
            self.send_json({"error": str(error)}, HTTPStatus.BAD_REQUEST)


if __name__ == "__main__":
    setup_database()
    print("Atharv Shop is ready at http://localhost:8000")
    ThreadingHTTPServer(("", 8000), AtharvShopHandler).serve_forever()
